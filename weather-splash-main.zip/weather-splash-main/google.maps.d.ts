// src/types/google.maps.d.ts
declare module 'google.maps' {
    export = google.maps;
  }
  

declare namespace google.maps {
    // Add any specific type definitions you need here, or leave it empty for now
  }
  
declare var google: any;

