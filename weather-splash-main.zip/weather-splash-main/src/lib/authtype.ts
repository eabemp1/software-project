export type Credentials = {
    email: string,
    password: string
}